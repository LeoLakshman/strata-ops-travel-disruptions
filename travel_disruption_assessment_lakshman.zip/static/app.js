/**
 * Strata Ops // U.S. Corporate Travel Disruption Intelligence Client
 * Handles real-time API communication, Leaflet flight route visualization,
 * animated probability dials, interactive action matrix, and traceable evidence filtering.
 */

let flightMap = null;
let currentAssessment = null;
let activeEvidenceFilter = 'all';

// Request Lifecycle & Concurrency Controllers
let activeAssessmentController = null;
let activeChatController = null;
let activeAirportController = null;

// Real-Time Visual Overlays State
let tomtomApiKey = localStorage.getItem('strata_tomtom_api_key') || '';
let tomtomTrafficLayer = null;
let tomtomIncidentsLayer = null;
let nexradRadarLayer = null;
let isTomTomTrafficActive = false;
let isTomTomIncidentsActive = false;
let isNexradRadarActive = false;

/**
 * High-Polish Operational Toast Notification
 */
function showToast(message, iconName = 'info', type = 'info') {
  const container = document.getElementById('opsToastContainer');
  if (!container) return;

  const toast = document.createElement('div');
  toast.className = 'ops-toast';

  let iconColor = 'text-blue-400';
  if (type === 'success') iconColor = 'text-emerald-400';
  if (type === 'warning') iconColor = 'text-amber-400';
  if (type === 'error') iconColor = 'text-rose-400';

  const safeIcon = (iconName || 'info').replace(/[^a-z0-9_-]/gi, '');
  toast.innerHTML = `
    <i data-lucide="${safeIcon}" class="w-4 h-4 ${iconColor} flex-shrink-0"></i>
    <span class="leading-tight">${escapeHtml(message)}</span>
  `;

  container.appendChild(toast);
  if (window.lucide) lucide.createIcons();

  setTimeout(() => {
    toast.style.opacity = '0';
    toast.style.transform = 'translateY(10px) scale(0.95)';
    toast.style.transition = 'all 0.25s cubic-bezier(0.16, 1, 0.3, 1)';
    setTimeout(() => toast.remove(), 260);
  }, 3200);
}

function getIsoDate(offsetDays = 0) {
  const d = new Date();
  d.setDate(d.getDate() + offsetDays);
  const yyyy = d.getFullYear();
  const mm = String(d.getMonth() + 1).padStart(2, '0');
  const dd = String(d.getDate()).padStart(2, '0');
  return `${yyyy}-${mm}-${dd}`;
}

function syncDatePresetButtons(selectedDate) {
  const todayBtn = document.getElementById('datePresetTodayBtn');
  const tmrwBtn = document.getElementById('datePresetTomorrowBtn');
  if (!todayBtn || !tmrwBtn) return;

  const todayStr = getIsoDate(0);
  const tmrwStr = getIsoDate(1);

  const activeCls = 'text-[10px] px-2.5 py-0.5 rounded-full bg-[#1a73e8] text-white font-semibold transition shadow-xs';
  const inactiveCls = 'text-[10px] px-2.5 py-0.5 rounded-full bg-[#f1f3f4] hover:bg-[#e8eaed] text-[#5f6368] font-medium transition';

  if (selectedDate === todayStr) {
    todayBtn.className = activeCls;
    tmrwBtn.className = inactiveCls;
  } else if (selectedDate === tmrwStr) {
    tmrwBtn.className = activeCls;
    todayBtn.className = inactiveCls;
  } else {
    todayBtn.className = inactiveCls;
    tmrwBtn.className = inactiveCls;
  }
}

document.addEventListener('DOMContentLoaded', () => {
  lucide.createIcons();
  initSettings();
  initFormHandlers();
  initMap();
  initMapLayerToggles();
  initJourneyChatAssistant();
  initWhatIfSimulator();

  const travelDateInput = document.getElementById('travelDateInput');
  const initialDate = travelDateInput?.value || getIsoDate(1);

  // Auto-trigger default query for instant demo on first load: JFK -> SFO tomorrow
  submitAssessment('JFK', 'SFO', initialDate, 'all_day');
});

/**
 * Settings & API Key handling (Gemini & TomTom Developer Keys)
 */
async function initSettings() {
  const settingsBtn = document.getElementById('settingsBtn');
  const settingsModal = document.getElementById('settingsModal');
  const closeSettingsBtn = document.getElementById('closeSettingsBtn');
  const saveKeyBtn = document.getElementById('saveKeyBtn');
  const clearKeyBtn = document.getElementById('clearKeyBtn');
  const keyInput = document.getElementById('geminiApiKeyInput');
  const tomtomInput = document.getElementById('tomtomApiKeyInput');
  const aiEngineLabel = document.getElementById('aiEngineLabel');
  const tomtomStatusIndicator = document.getElementById('tomtomStatusIndicator');

  // Load saved Gemini Key
  const savedGeminiKey = localStorage.getItem('strata_gemini_api_key') || '';
  if (savedGeminiKey && keyInput) {
    keyInput.value = savedGeminiKey;
    aiEngineLabel.textContent = 'Gemini 2.5 Active';
  }

  // Load saved TomTom Key
  const savedTomTomKey = localStorage.getItem('strata_tomtom_api_key') || '';
  if (savedTomTomKey) {
    tomtomApiKey = savedTomTomKey;
    if (tomtomInput) tomtomInput.value = savedTomTomKey;
  }

  // Auto-sync config from backend if configured in .env
  try {
    const cfgRes = await fetch('/api/config');
    if (cfgRes.ok) {
      const cfg = await cfgRes.json();
      if (cfg.tomtom_key && !tomtomApiKey) {
        tomtomApiKey = cfg.tomtom_key;
        if (tomtomInput) tomtomInput.value = tomtomApiKey;
      }
    }
  } catch (e) {
    // Non-fatal config fetch
  }

  updateTomTomUIStatus();

  if (settingsBtn) {
    settingsBtn.addEventListener('click', () => {
      settingsModal.classList.remove('hidden');
      lucide.createIcons();
    });
  }

  if (closeSettingsBtn) {
    closeSettingsBtn.addEventListener('click', () => {
      settingsModal.classList.add('hidden');
    });
  }

  if (saveKeyBtn) {
    saveKeyBtn.addEventListener('click', () => {
      // 1. Gemini Key
      const gVal = keyInput ? keyInput.value.trim() : '';
      if (gVal) {
        localStorage.setItem('strata_gemini_api_key', gVal);
        aiEngineLabel.textContent = 'Gemini 2.5 Active';
      } else {
        localStorage.removeItem('strata_gemini_api_key');
        aiEngineLabel.textContent = 'AI Engine';
      }

      // 2. TomTom Key
      const tVal = tomtomInput ? tomtomInput.value.trim() : '';
      if (tVal) {
        localStorage.setItem('strata_tomtom_api_key', tVal);
        tomtomApiKey = tVal;
      } else {
        localStorage.removeItem('strata_tomtom_api_key');
        tomtomApiKey = '';
      }

      updateTomTomUIStatus();
      applyBaseMapTiles();
      refreshActiveTomTomLayers();

      settingsModal.classList.add('hidden');
      showToast('API credentials saved & telemetry synchronized', 'check-circle', 'success');
    });
  }

  if (clearKeyBtn) {
    clearKeyBtn.addEventListener('click', () => {
      if (keyInput) keyInput.value = '';
      if (tomtomInput) tomtomInput.value = '';
      localStorage.removeItem('strata_gemini_api_key');
      localStorage.removeItem('strata_tomtom_api_key');
      tomtomApiKey = '';
      aiEngineLabel.textContent = 'AI Engine';
      updateTomTomUIStatus();
      applyBaseMapTiles();
      refreshActiveTomTomLayers();
      settingsModal.classList.add('hidden');
      showToast('API credentials cleared from local storage', 'trash-2', 'warning');
    });
  }
}

function updateTomTomUIStatus() {
  const tomtomStatusIndicator = document.getElementById('tomtomStatusIndicator');
  if (!tomtomStatusIndicator) return;
  if (tomtomApiKey) {
    tomtomStatusIndicator.innerHTML = `<span class="text-emerald-400 font-semibold flex items-center gap-1"><span class="w-1.5 h-1.5 rounded-full bg-emerald-400"></span>TomTom Key Active</span>`;
  } else {
    tomtomStatusIndicator.innerHTML = `<span class="text-gray-500">TomTom: No Key</span>`;
  }
}

function refreshActiveTomTomLayers() {
  if (!flightMap) return;
  if (isTomTomTrafficActive) {
    if (tomtomTrafficLayer) flightMap.removeLayer(tomtomTrafficLayer);
    if (tomtomApiKey) {
      tomtomTrafficLayer = L.tileLayer(
        `https://api.tomtom.com/traffic/map/4/tile/flow/relative0/{z}/{x}/{y}.png?key=${tomtomApiKey}`,
        { maxZoom: 18, opacity: 0.85, zIndex: 15 }
      ).addTo(flightMap);
    } else {
      isTomTomTrafficActive = false;
      const dot = document.getElementById('tomtomTrafficDot');
      if (dot) dot.className = 'w-2 h-2 rounded-full bg-gray-500';
    }
  }

  if (isTomTomIncidentsActive) {
    if (tomtomIncidentsLayer) flightMap.removeLayer(tomtomIncidentsLayer);
    if (tomtomApiKey) {
      tomtomIncidentsLayer = L.tileLayer(
        `https://api.tomtom.com/traffic/map/4/tile/incidents/s0/{z}/{x}/{y}.png?key=${tomtomApiKey}`,
        { maxZoom: 18, opacity: 0.9, zIndex: 16 }
      ).addTo(flightMap);
    } else {
      isTomTomIncidentsActive = false;
      const dot = document.getElementById('tomtomIncidentsDot');
      if (dot) dot.className = 'w-2 h-2 rounded-full bg-gray-500';
    }
  }
}

/**
 * Interactive Visual Map Layer Toggles: TomTom Traffic, Incidents & NOAA Radar
 */
function initMapLayerToggles() {
  const trafficBtn = document.getElementById('toggleTomTomTrafficBtn');
  const incidentsBtn = document.getElementById('toggleTomTomIncidentsBtn');
  const radarBtn = document.getElementById('toggleNexradRadarBtn');
  const trafficDot = document.getElementById('tomtomTrafficDot');
  const incidentsDot = document.getElementById('tomtomIncidentsDot');
  const radarDot = document.getElementById('nexradRadarDot');
  const settingsModal = document.getElementById('settingsModal');

  // 1. Toggle TomTom Traffic Flow
  if (trafficBtn) {
    trafficBtn.addEventListener('click', () => {
      if (!tomtomApiKey) {
        // Prompt for key
        if (settingsModal) {
          settingsModal.classList.remove('hidden');
          const tInput = document.getElementById('tomtomApiKeyInput');
          if (tInput) tInput.focus();
        }
        return;
      }

      isTomTomTrafficActive = !isTomTomTrafficActive;
      if (isTomTomTrafficActive) {
        if (!tomtomTrafficLayer) {
          tomtomTrafficLayer = L.tileLayer(
            `https://api.tomtom.com/traffic/map/4/tile/flow/relative0/{z}/{x}/{y}.png?key=${tomtomApiKey}`,
            { maxZoom: 18, opacity: 0.85, zIndex: 15 }
          );
        }
        if (flightMap) tomtomTrafficLayer.addTo(flightMap);
        trafficDot.className = 'w-2 h-2 rounded-full bg-emerald-400 animate-pulse';
      } else {
        if (flightMap && tomtomTrafficLayer) flightMap.removeLayer(tomtomTrafficLayer);
        trafficDot.className = 'w-2 h-2 rounded-full bg-gray-500';
      }
    });
  }

  // 2. Toggle TomTom Real-Time Incidents
  if (incidentsBtn) {
    incidentsBtn.addEventListener('click', () => {
      if (!tomtomApiKey) {
        if (settingsModal) {
          settingsModal.classList.remove('hidden');
          const tInput = document.getElementById('tomtomApiKeyInput');
          if (tInput) tInput.focus();
        }
        return;
      }

      isTomTomIncidentsActive = !isTomTomIncidentsActive;
      if (isTomTomIncidentsActive) {
        if (!tomtomIncidentsLayer) {
          tomtomIncidentsLayer = L.tileLayer(
            `https://api.tomtom.com/traffic/map/4/tile/incidents/s0/{z}/{x}/{y}.png?key=${tomtomApiKey}`,
            { maxZoom: 18, opacity: 0.9, zIndex: 16 }
          );
        }
        if (flightMap) tomtomIncidentsLayer.addTo(flightMap);
        incidentsDot.className = 'w-2 h-2 rounded-full bg-amber-400 animate-pulse';
      } else {
        if (flightMap && tomtomIncidentsLayer) flightMap.removeLayer(tomtomIncidentsLayer);
        incidentsDot.className = 'w-2 h-2 rounded-full bg-gray-500';
      }
    });
  }

  // 3. Toggle Free NOAA NEXRAD Weather Radar
  if (radarBtn) {
    radarBtn.addEventListener('click', () => {
      isNexradRadarActive = !isNexradRadarActive;
      if (isNexradRadarActive) {
        if (!nexradRadarLayer) {
          nexradRadarLayer = L.tileLayer.wms('https://mesonet.agron.iastate.edu/cgi-bin/wms/nexrad/n0r.cgi', {
            layers: 'nexrad-n0r-900913',
            format: 'image/png',
            transparent: true,
            opacity: 0.55,
            zIndex: 14,
          });
        }
        if (flightMap) nexradRadarLayer.addTo(flightMap);
        radarDot.className = 'w-2 h-2 rounded-full bg-blue-400 animate-pulse';
      } else {
        if (flightMap && nexradRadarLayer) flightMap.removeLayer(nexradRadarLayer);
        radarDot.className = 'w-2 h-2 rounded-full bg-gray-500';
      }
    });
  }
}


/**
 * Live Airport Autocomplete for Origin & Destination
 * Equipped with AbortController request cancellation and keyboard navigation
 */
function setupAirportAutocomplete(inputId, suggestionsId) {
  const input = document.getElementById(inputId);
  const box = document.getElementById(suggestionsId);
  if (!input || !box) return;

  let debounceTimer = null;
  let activeIndex = -1;

  input.addEventListener('input', () => {
    clearTimeout(debounceTimer);
    activeIndex = -1;
    const val = input.value.trim();
    if (val.length < 1) {
      box.classList.add('hidden');
      box.innerHTML = '';
      return;
    }

    debounceTimer = setTimeout(async () => {
      if (activeAirportController) {
        activeAirportController.abort();
      }
      activeAirportController = new AbortController();

      try {
        const resp = await fetch(`/api/airports?q=${encodeURIComponent(val)}`, {
          signal: activeAirportController.signal
        });
        if (!resp.ok) return;
        const data = await resp.json();
        const airports = data.airports || [];
        if (airports.length === 0) {
          box.classList.add('hidden');
          box.innerHTML = '';
          return;
        }

        box.innerHTML = '';
        airports.forEach((apt, idx) => {
          const item = document.createElement('button');
          item.type = 'button';
          item.setAttribute('data-idx', idx);
          item.className = 'autocomplete-item w-full px-3.5 py-2.5 text-left hover:bg-[#f1f3f4] flex items-center justify-between group transition cursor-pointer text-xs';
          item.innerHTML = `
            <div class="truncate mr-2">
              <span class="font-mono font-bold text-[#1a73e8] group-hover:text-[#1557b0]">${apt.iata}</span>
              <span class="text-[11px] text-[#202124] ml-1.5 font-medium">${apt.city}${apt.state ? ', ' + apt.state : ''}</span>
              <div class="text-[10px] text-[#5f6368] truncate">${apt.name}</div>
            </div>
            <span class="text-[9px] font-mono text-[#5f6368] uppercase px-1.5 py-0.5 rounded bg-[#f1f3f4] border border-[#dadce0] flex-shrink-0">${apt.icao || ''}</span>
          `;
          item.addEventListener('click', (e) => {
            e.preventDefault();
            input.value = apt.iata;
            box.classList.add('hidden');
            box.innerHTML = '';
          });
          box.appendChild(item);
        });

        box.classList.remove('hidden');
      } catch (e) {
        if (e.name === 'AbortError') return;
      }
    }, 120);
  });

  document.addEventListener('click', (e) => {
    if (!input.contains(e.target) && !box.contains(e.target)) {
      box.classList.add('hidden');
    }
  });

  input.addEventListener('keydown', (e) => {
    const items = box.querySelectorAll('.autocomplete-item');
    if (box.classList.contains('hidden') || items.length === 0) {
      return;
    }

    if (e.key === 'ArrowDown') {
      e.preventDefault();
      activeIndex = (activeIndex + 1) % items.length;
      items.forEach((item, idx) => {
        item.classList.toggle('bg-[#e8f0fe]', idx === activeIndex);
      });
      items[activeIndex].scrollIntoView({ block: 'nearest' });
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      activeIndex = (activeIndex - 1 + items.length) % items.length;
      items.forEach((item, idx) => {
        item.classList.toggle('bg-[#e8f0fe]', idx === activeIndex);
      });
      items[activeIndex].scrollIntoView({ block: 'nearest' });
    } else if (e.key === 'Enter') {
      if (activeIndex >= 0 && items[activeIndex]) {
        e.preventDefault();
        items[activeIndex].click();
      }
    } else if (e.key === 'Escape') {
      box.classList.add('hidden');
    }
  });
}

/**
 * Form and Interactive Controls
 */
function initFormHandlers() {
  const form = document.getElementById('assessmentForm');
  const originInput = document.getElementById('originInput');
  const destInput = document.getElementById('destinationInput');
  const swapBtn = document.getElementById('swapAirportsBtn');
  const travelDateInput = document.getElementById('travelDateInput');
  const todayBtn = document.getElementById('datePresetTodayBtn');
  const tmrwBtn = document.getElementById('datePresetTomorrowBtn');
  const exportBtn = document.getElementById('exportBriefingBtn');

  // Swap airports
  swapBtn.addEventListener('click', () => {
    const tmp = originInput.value;
    originInput.value = destInput.value;
    destInput.value = tmp;
    showToast(`Swapped corridor route: ${originInput.value} ⇄ ${destInput.value}`, 'arrow-left-right', 'info');
  });

  // Airport Autocomplete
  setupAirportAutocomplete('originInput', 'originSuggestions');
  setupAirportAutocomplete('destinationInput', 'destinationSuggestions');

  // Date input initialization and listener
  if (travelDateInput) {
    if (!travelDateInput.value) {
      travelDateInput.value = getIsoDate(1);
    }
    syncDatePresetButtons(travelDateInput.value);

    travelDateInput.addEventListener('change', () => {
      syncDatePresetButtons(travelDateInput.value);
    });
  }

  // Micro-preset buttons
  if (todayBtn) {
    todayBtn.addEventListener('click', () => {
      if (travelDateInput) {
        travelDateInput.value = getIsoDate(0);
        syncDatePresetButtons(travelDateInput.value);
      }
    });
  }

  if (tmrwBtn) {
    tmrwBtn.addEventListener('click', () => {
      if (travelDateInput) {
        travelDateInput.value = getIsoDate(1);
        syncDatePresetButtons(travelDateInput.value);
      }
    });
  }

  // Quick Chips
  document.querySelectorAll('.quick-chip').forEach(btn => {
    btn.addEventListener('click', () => {
      const targetId = btn.getAttribute('data-target');
      const code = btn.getAttribute('data-code');
      const el = document.getElementById(targetId);
      if (el) el.value = code;
    });
  });

  // Presets
  document.querySelectorAll('.preset-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const orig = btn.getAttribute('data-orig');
      const dest = btn.getAttribute('data-dest');
      const dTag = btn.getAttribute('data-date');
      const targetDate = (dTag === 'today') ? getIsoDate(0) : getIsoDate(1);
      originInput.value = orig;
      destInput.value = dest;
      if (travelDateInput) {
        travelDateInput.value = targetDate;
        syncDatePresetButtons(targetDate);
      }
      showToast(`Loaded preset corridor: ${orig} → ${dest}`, 'zap', 'info');
      submitAssessment(orig, dest, targetDate, 'all_day');
    });
  });

  // Tabs for Action Matrix
  const travelerTab = document.getElementById('travelerTabBtn');
  const opsTab = document.getElementById('opsTabBtn');
  const travelerList = document.getElementById('travelerActionsList');
  const opsList = document.getElementById('opsActionsList');

  // Corridor Mode tabs
  document.querySelectorAll('.mode-tab-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.mode-tab-btn').forEach(b => {
        b.classList.remove('font-semibold', 'text-white', 'bg-[#1a73e8]', 'shadow-sm');
        b.classList.add('font-medium', 'text-[#5f6368]');
      });
      btn.classList.add('font-semibold', 'text-white', 'bg-[#1a73e8]', 'shadow-sm');
      btn.classList.remove('text-[#5f6368]', 'font-medium');
      const mode = btn.getAttribute('data-mode');
      document.getElementById('travelModeInput').value = mode;

      // Toggle Highway preference bar
      const hwContainer = document.getElementById('highwayPrefContainer');
      if (hwContainer) {
        if (mode === 'road' || mode === 'multimodal') {
          hwContainer.classList.remove('hidden');
        } else {
          hwContainer.classList.add('hidden');
        }
      }

      // Update Form Titles
      const formTitle = document.getElementById('formTitleText');
      const formSub = document.getElementById('formSubTitleText');
      if (formTitle && formSub) {
        if (mode === 'road') {
          formTitle.textContent = 'U.S. Interstate & State Highway Roadway Disruption Assessment';
          formSub.textContent = 'Query road surface weather hazards, black ice, mountain pass chain controls, and strategic waypoint halts.';
        } else if (mode === 'multimodal') {
          formTitle.textContent = 'U.S. Multimodal Air & Highway Corridor Assessment';
          formSub.textContent = 'Cross-analyze flight delays, airport ground stops, and roadway driving alternatives.';
        } else {
          formTitle.textContent = 'U.S. Flight Disruption Risk Assessment';
          formSub.textContent = 'Query real-time FAA airspace status, NOAA terminal meteorology, NWS advisories, and corridor atmospheric forecasts.';
        }
      }
      lucide.createIcons();
    });
  });

  // Highway Preference buttons
  document.querySelectorAll('.hw-pref-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.hw-pref-btn').forEach(b => {
        b.classList.remove('font-semibold', 'text-white', 'bg-[#188038]');
        b.classList.add('font-medium', 'text-[#5f6368]');
      });
      btn.classList.add('font-semibold', 'text-white', 'bg-[#188038]');
      btn.classList.remove('font-medium', 'text-[#5f6368]');
      const pref = btn.getAttribute('data-pref');
      const input = document.getElementById('highwayPrefInput');
      if (input) input.value = pref;
    });
  });

  // Halt Frequency Selector buttons
  document.querySelectorAll('.halt-count-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.halt-count-btn').forEach(b => {
        b.classList.remove('font-semibold', 'text-white', 'bg-[#1a73e8]');
        b.classList.add('font-medium', 'text-[#5f6368]');
      });
      btn.classList.add('font-semibold', 'text-white', 'bg-[#1a73e8]');
      btn.classList.remove('font-medium', 'text-[#5f6368]');
      const halts = btn.getAttribute('data-halts');
      const input = document.getElementById('desiredHaltCountInput');
      if (input) input.value = halts;
    });
  });

  travelerTab.addEventListener('click', () => {
    travelerTab.classList.add('font-semibold', 'text-white', 'bg-[#1a73e8]', 'shadow-sm');
    travelerTab.classList.remove('font-medium', 'text-[#5f6368]');
    opsTab.classList.remove('font-semibold', 'text-white', 'bg-[#1a73e8]', 'shadow-sm');
    opsTab.classList.add('font-medium', 'text-[#5f6368]');
    travelerList.classList.remove('hidden');
    opsList.classList.add('hidden');
  });

  opsTab.addEventListener('click', () => {
    opsTab.classList.add('font-semibold', 'text-white', 'bg-[#1a73e8]', 'shadow-sm');
    opsTab.classList.remove('font-medium', 'text-[#5f6368]');
    travelerTab.classList.remove('font-semibold', 'text-white', 'bg-[#1a73e8]', 'shadow-sm');
    travelerTab.classList.add('font-medium', 'text-[#5f6368]');
    opsList.classList.remove('hidden');
    travelerList.classList.add('hidden');
  });

  // Evidence Filters
  document.querySelectorAll('.ev-filter-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.ev-filter-btn').forEach(b => {
        b.classList.remove('active');
      });
      btn.classList.add('active');
      activeEvidenceFilter = btn.getAttribute('data-filter');
      renderEvidence();
    });
  });

  // Export Briefing
  exportBtn.addEventListener('click', () => {
    window.print();
  });

  // Form Submit
  form.addEventListener('submit', (e) => {
    e.preventDefault();
    const orig = originInput.value.trim();
    const dest = destInput.value.trim();
    const d = travelDateInput ? travelDateInput.value : getIsoDate(1);
    const win = document.getElementById('timeWindowSelect').value;
    submitAssessment(orig, dest, d, win);
  });
}

/**
 * Execute Assessment Request to Backend
 * Includes AbortController concurrency management to prevent network race conditions
 */
async function submitAssessment(origin, destination, dateVal, timeWindow) {
  if (activeAssessmentController) {
    activeAssessmentController.abort();
  }
  activeAssessmentController = new AbortController();

  const loading = document.getElementById('loadingState');
  const results = document.getElementById('resultsContainer');
  const errorBox = document.getElementById('errorBox');
  const submitBtn = document.getElementById('submitBtn');
  const loadingStatusText = document.getElementById('loadingStatusText');
  const exportBtn = document.getElementById('exportBriefingBtn');

  errorBox.classList.add('hidden');
  loading.classList.remove('hidden');
  results.classList.add('hidden');
  submitBtn.disabled = true;

  const travelMode = document.getElementById('travelModeInput')?.value || 'air';
  const highwayPref = document.getElementById('highwayPrefInput')?.value || 'interstate';

  // Progressive loading status message (adapted to travel mode)
  const statusMessages = (travelMode === 'road') ? [
    'Scanning NWS Active Road Weather Watches, Warnings & Winter Advisories...',
    'Analyzing State DOT 511 Mountain Pass Chain Controls & Black Ice Sensors...',
    'Computing Interstate vs State Highway Corridor Routing Trajectories...',
    'Evaluating Tactical Halts (EV/Fuel Travel Plazas) & Motel Contingencies...',
    'Executing Multi-Source Roadway Risk Fusion & Synthesis...',
  ] : [
    'Querying FAA Command Center for Ground Stops & GDPs...',
    'Fetching NOAA Aviation Weather METARs & TAF forecasts...',
    'Scanning NWS Active Severe Weather Watches & Warnings...',
    'Running High-Resolution Corridor Atmospheric Forecasts...',
    'Executing Multi-Signal Bayesian Risk Fusion & LLM Synthesis...',
  ];
  let msgIdx = 0;
  const timer = setInterval(() => {
    msgIdx = (msgIdx + 1) % statusMessages.length;
    loadingStatusText.textContent = statusMessages[msgIdx];
  }, 900);

  const apiKey = localStorage.getItem('strata_gemini_api_key') || null;
  const haltVal = document.getElementById('desiredHaltCountInput')?.value || 'auto';
  const desiredHaltCount = haltVal === 'auto' ? null : parseInt(haltVal, 10);

  try {
    const resp = await fetch('/api/assess', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      signal: activeAssessmentController.signal,
      body: JSON.stringify({
        origin: origin,
        destination: destination,
        date: dateVal,
        time_window: timeWindow,
        travel_mode: travelMode,
        highway_preference: highwayPref,
        desired_halt_count: desiredHaltCount,
        gemini_api_key: apiKey,
      }),
    });

    clearInterval(timer);

    if (!resp.ok) {
      const errData = await resp.json().catch(() => ({ detail: 'Request failed.' }));
      throw new Error(errData.detail || 'Failed to complete disruption assessment.');
    }

    const data = await resp.json();
    currentAssessment = data;

    loading.classList.add('hidden');
    results.classList.remove('hidden');
    exportBtn.classList.remove('hidden');
    exportBtn.classList.add('flex');
    submitBtn.disabled = false;

    renderResults(data);

    const toastLevelType = data.risk_level === 'LOW' ? 'success' : (data.risk_level === 'MODERATE' ? 'warning' : 'error');
    showToast(`Assessment complete: ${data.composite_risk_score}/100 (${data.risk_level})`, 'shield-alert', toastLevelType);

    if (flightMap) {
      setTimeout(() => {
        flightMap.invalidateSize();
        updateMap(data.route, data.travel_mode, data.halt_suggestions, data.stay_recommendations);
      }, 60);
    }
  } catch (err) {
    clearInterval(timer);
    if (err.name === 'AbortError') {
      // In-flight request was cleanly superseded by a newer user search
      return;
    }
    loading.classList.add('hidden');
    submitBtn.disabled = false;
    errorBox.classList.remove('hidden');
    document.getElementById('errorMessage').textContent = err.message;
  }
}

/**
 * Populate Results in UI
 */
function renderResults(data) {
  // 1. Risk Score & Level
  const score = data.composite_risk_score;
  const level = data.risk_level;

  document.getElementById('riskScoreNumber').textContent = score;

  // Gauge Meter SVG animation
  const circle = document.getElementById('riskMeterCircle');
  const circumference = 251.2; // 2 * pi * 40
  const offset = circumference - (score / 100) * circumference;
  circle.style.strokeDashoffset = offset;

  // Gauge color based on level
  circle.classList.remove('text-[#188038]', 'text-[#f29900]', 'text-[#d93025]', 'text-[#be123c]', 'text-emerald-500', 'text-amber-500', 'text-rose-500', 'text-red-600');
  const banner = document.getElementById('riskBanner');
  banner.classList.remove('risk-card-low', 'risk-card-moderate', 'risk-card-high', 'risk-card-critical', 'risk-low', 'risk-moderate', 'risk-high', 'risk-critical');

  const badge = document.getElementById('riskLevelBadge');
  badge.className = 'text-xs font-bold uppercase tracking-wider px-3 py-1 rounded-full border';

  if (level === 'LOW') {
    circle.classList.add('text-[#188038]');
    banner.classList.add('risk-card-low');
    badge.classList.add('bg-[#e6f4ea]', 'text-[#137333]', 'border-[#a8dab5]');
    badge.textContent = 'LOW DISRUPTION RISK';
  } else if (level === 'MODERATE') {
    circle.classList.add('text-[#f29900]');
    banner.classList.add('risk-card-moderate');
    badge.classList.add('bg-[#fef7e0]', 'text-[#b45309]', 'border-[#fdd663]');
    badge.textContent = 'MODERATE DISRUPTION RISK';
  } else if (level === 'HIGH') {
    circle.classList.add('text-[#d93025]');
    banner.classList.add('risk-card-high');
    badge.classList.add('bg-[#fce8e6]', 'text-[#c5221f]', 'border-[#f5c2c7]');
    badge.textContent = 'HIGH DISRUPTION RISK';
  } else {
    circle.classList.add('text-[#be123c]');
    banner.classList.add('risk-card-critical');
    badge.classList.add('bg-[#ffe4e6]', 'text-[#9f1239]', 'border-[#fda4af]');
    badge.textContent = 'CRITICAL DISRUPTION RISK';
  }

  // Route headline & verdict
  const isRoad = data.travel_mode === 'road';
  const isMultimodal = data.travel_mode === 'multimodal';

  if (isRoad) {
    document.getElementById('routeHeadlineBadge').textContent = `${data.route.origin.city} → ${data.route.destination.city} (DRIVE • ${data.route.travel_date.toUpperCase()})`;
    document.getElementById('delayProbTitle').textContent = 'Highway Delay Risk';
    document.getElementById('cancelProbTitle').textContent = 'Pass Closure Risk';
    document.getElementById('connRiskTitle').textContent = 'Fatigue / Slippage';

    document.getElementById('mapSectionTitle').textContent = 'Highway Corridor & Tactical Waypoints';
    document.getElementById('dimensionsSectionTitle').textContent = 'Roadway Risk Decomposition';
    document.getElementById('airspaceScoreLabel').textContent = 'Mountain Pass & Chain Controls';
    document.getElementById('arrWeatherScoreLabel').textContent = 'Destination Approach Road Surface';
    document.getElementById('depWeatherScoreLabel').textContent = 'Departure Beltway & Road Surface';
    document.getElementById('enrouteScoreLabel').textContent = 'Highway Corridor Crosswinds & Rain';

    const hway = (data.route.primary_interstates || [])[0] || 'Interstate Mainline';
    document.getElementById('routeFlightStats').textContent = `Drive: ${data.route.driving_distance_miles?.toLocaleString() || 'N/A'} mi • Est. ${data.route.driving_time_est || 'N/A'} • ${hway}`;
  } else {
    document.getElementById('routeHeadlineBadge').textContent = `${data.route.origin.iata} → ${data.route.destination.iata} (${isMultimodal ? 'MULTIMODAL' : 'AIR'} • ${data.route.travel_date.toUpperCase()})`;
    document.getElementById('delayProbTitle').textContent = 'Delay Risk';
    document.getElementById('cancelProbTitle').textContent = 'Cancellation';
    document.getElementById('connRiskTitle').textContent = 'Connection Risk';

    document.getElementById('mapSectionTitle').textContent = 'Airspace Corridor & Route Geometry';
    document.getElementById('dimensionsSectionTitle').textContent = 'Risk Decomposition by Dimension';
    document.getElementById('airspaceScoreLabel').textContent = 'FAA Airspace Programs & Capacity';
    document.getElementById('arrWeatherScoreLabel').textContent = 'Destination Terminal Conditions';
    document.getElementById('depWeatherScoreLabel').textContent = 'Departure Terminal Conditions';
    document.getElementById('enrouteScoreLabel').textContent = 'En-Route Turbulence & AIRSIGMETs';

    document.getElementById('routeFlightStats').textContent = `${data.route.distance_miles.toLocaleString()} mi • Est. ${data.route.flight_time_est}`;
  }

  document.getElementById('executiveVerdictText').textContent = data.executive_verdict;
  document.getElementById('headlineRiskSummary').textContent = data.headline_risk_summary;

  // 3 Probability Metrics
  document.getElementById('delayProbVal').textContent = `${data.delay_probability}%`;
  document.getElementById('delayRangeVal').textContent = data.expected_delay_range;
  document.getElementById('cancelProbVal').textContent = `${data.cancellation_probability}%`;
  document.getElementById('connRiskVal').textContent = `${data.missed_connection_risk}%`;

  // 4 Dimension Scores
  const dims = data.dimension_scores;
  setMeter('airspaceScoreVal', 'airspaceScoreBar', dims.airspace_atc);
  setMeter('arrWeatherScoreVal', 'arrWeatherScoreBar', dims.arrival_terminal);
  setMeter('depWeatherScoreVal', 'depWeatherScoreBar', dims.departure_terminal);
  setMeter('enrouteScoreVal', 'enrouteScoreBar', dims.enroute_corridor);

  // Hourly Timeline
  renderHourlyTimeline(data.hourly_timeline);

  // Actions
  renderActions(data.recommendations);

  // Uncertainty
  renderUncertainty(data.uncertainty);

  // AI Briefing
  document.getElementById('aiBriefingText').innerHTML = formatMarkdown(data.ai_briefing);
  document.getElementById('aiEngineBadge').textContent = data.engine_used;

  // Roadway Corridor, Halts & Stays
  renderRoadwayAndStays(data);

  // Alternate Routes & Bypasses
  renderAlternateRoutes(data.alternate_routes);

  // Evidence Dossier
  renderEvidence();

  // Update Right-Side Chat Dock Context Badges & Chips
  const routeBadgeText = `${data.route.origin.iata} → ${data.route.destination.iata} (${data.travel_mode.toUpperCase()})`;
  const chatRouteBadge = document.getElementById('chatRouteContextBadge');
  const floatRouteBadge = document.getElementById('floatingChatRouteBadge');
  if (chatRouteBadge) chatRouteBadge.textContent = routeBadgeText;
  if (floatRouteBadge) floatRouteBadge.textContent = routeBadgeText;

  const chatChipsEl = document.getElementById('journeyChatChips');
  if (chatChipsEl) {
    chatChipsEl.innerHTML = '';
    const chipItems = data.travel_mode === 'road' ? [
      { label: '⛽ Fuel & Fatigue Stops', prompt: 'Where should I stop for fuel and fatigue breaks?' },
      { label: '📍 Only One Halt', prompt: 'What if I need only one halt?' },
      { label: '⏱️ Best Departure Window', prompt: 'What is the best departure window to avoid traffic?' },
      { label: '📋 Draft Manager Email', prompt: 'Draft an email to my manager about my road trip schedule' },
    ] : [
      { label: '🛡️ Delay Protocol', prompt: 'What should I do if my flight or drive is delayed?' },
      { label: '🚗 Flight vs Drive', prompt: 'Is driving better or faster than flying for this route?' },
      { label: '📋 Draft Manager Email', prompt: 'Draft a delay update email for my team or client' },
      { label: '🔄 Alternate Routes', prompt: 'What alternate routes or airports can I take?' },
    ];

    chipItems.forEach(item => {
      const btn = document.createElement('button');
      btn.type = 'button';
      btn.className = 'journey-chip google-chip text-[10px] cursor-pointer';
      btn.setAttribute('data-prompt', item.prompt);
      btn.textContent = item.label;
      btn.addEventListener('click', () => {
        const chatInput = document.getElementById('journeyChatInput');
        const chatForm = document.getElementById('journeyChatForm');
        if (chatInput && chatForm) {
          chatInput.value = item.prompt;
          chatForm.dispatchEvent(new Event('submit'));
        }
      });
      chatChipsEl.appendChild(btn);
    });
  }

  lucide.createIcons();
}

function setMeter(textId, barId, score) {
  document.getElementById(textId).textContent = `${score} / 100`;
  const bar = document.getElementById(barId);
  bar.style.width = `${score}%`;
  bar.className = 'h-full rounded-full transition-all duration-700';
  if (score >= 70) {
    bar.classList.add('bg-rose-500');
  } else if (score >= 40) {
    bar.classList.add('bg-amber-500');
  } else {
    bar.classList.add('bg-emerald-500');
  }
}

/**
 * Leaflet Map Render
 */
let baseMapLayer = null;

function applyBaseMapTiles() {
  if (!flightMap) return;
  if (baseMapLayer) {
    flightMap.removeLayer(baseMapLayer);
    baseMapLayer = null;
  }

  if (tomtomApiKey) {
    // Official TomTom Main Day tiles (Clean Google Maps style)
    baseMapLayer = L.tileLayer(
      `https://api.tomtom.com/map/1/tile/basic/main/{z}/{x}/{y}.png?key=${tomtomApiKey}`,
      { maxZoom: 18, zIndex: 1 }
    ).addTo(flightMap);
  } else {
    // High-Clarity Google Maps style CartoDB Voyager tiles (Clean, Free, Zero-Watermark)
    baseMapLayer = L.tileLayer(
      'https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png',
      { maxZoom: 18, zIndex: 1, attribution: '&copy; OpenStreetMap &copy; CARTO', subdomains: 'abcd' }
    ).addTo(flightMap);
  }
}

function initMap() {
  const mapEl = document.getElementById('mapContainer');
  if (!mapEl) return;
  flightMap = L.map('mapContainer', {
    zoomControl: false,
    attributionControl: false,
  }).setView([39.8283, -98.5795], 4);

  applyBaseMapTiles();

  // Responsive map viewport adjustment handler
  let resizeTimer = null;
  window.addEventListener('resize', () => {
    clearTimeout(resizeTimer);
    resizeTimer = setTimeout(() => {
      if (flightMap) flightMap.invalidateSize();
    }, 150);
  });
}

/**
 * Real-World Highway Route Geometry Fetcher
 * Supports intermediate via-points to enforce Interstate corridors (e.g. I-20 via Abilene, TX)
 * Tries TomTom Routing API if user key is configured; otherwise uses high-accuracy OSRM driving geometry.
 */
async function fetchRoadGeometry(origLat, origLon, destLat, destLon, viaLat = null, viaLon = null) {
  // 1. TomTom Calculate Route (Fastest + Traffic) if key is provided
  if (tomtomApiKey) {
    try {
      let routePath = `${origLat},${origLon}`;
      if (viaLat && viaLon) {
        routePath += `:${viaLat},${viaLon}`;
      }
      routePath += `:${destLat},${destLon}`;
      const url = `https://api.tomtom.com/routing/1/calculateRoute/${routePath}/json?key=${tomtomApiKey}&routeType=fastest&traffic=true`;
      const res = await fetch(url);
      if (res.ok) {
        const data = await res.json();
        if (data.routes && data.routes[0] && data.routes[0].legs) {
          let points = [];
          data.routes[0].legs.forEach(leg => {
            if (leg.points) {
              leg.points.forEach(p => points.push([p.latitude, p.longitude]));
            }
          });
          if (points.length > 5) return points;
        }
      }
    } catch (e) {
      console.warn('TomTom routing API query failed, falling back to OSRM:', e);
    }
  }

  // 2. High-Accuracy OSRM Real Road Highway Engine (Zero-Key, Real Highway Turns)
  try {
    let coordsStr = `${origLon},${origLat}`;
    if (viaLat && viaLon) {
      coordsStr += `;${viaLon},${viaLat}`;
    }
    coordsStr += `;${destLon},${destLat}`;
    const osrmUrl = `https://router.project-osrm.org/route/v1/driving/${coordsStr}?overview=full&geometries=geojson`;
    const res = await fetch(osrmUrl);
    if (res.ok) {
      const data = await res.json();
      if (data.routes && data.routes[0] && data.routes[0].geometry && data.routes[0].geometry.coordinates) {
        // OSRM coordinates are [lon, lat], Leaflet polyline expects [lat, lon]
        return data.routes[0].geometry.coordinates.map(coord => [coord[1], coord[0]]);
      }
    }
  } catch (e) {
    console.warn('OSRM routing query failed:', e);
  }

  return null;
}

let currentMapRenderId = 0;

async function updateMap(route, travelMode = 'air', halts = [], stays = []) {
  if (!flightMap) return;
  const renderId = ++currentMapRenderId;

  // Clear existing layers
  flightMap.eachLayer(layer => {
    if (layer instanceof L.Marker || layer instanceof L.Polyline) {
      flightMap.removeLayer(layer);
    }
  });

  const origLat = route.origin.lat;
  const origLon = route.origin.lon;
  const destLat = route.destination.lat;
  const destLon = route.destination.lon;
  const allCoords = [[origLat, origLon], [destLat, destLon]];

  if (travelMode === 'road') {
    // Determine Interstate via waypoint or major halt to pin the highway polyline to the Interstate
    let viaLat = null;
    let viaLon = null;
    if (route.interstate_via_waypoint && route.interstate_via_waypoint.lat) {
      viaLat = route.interstate_via_waypoint.lat;
      viaLon = route.interstate_via_waypoint.lon;
    } else if (halts && halts.length > 0 && halts[0].lat && route.highway_preference === 'interstate') {
      viaLat = halts[0].lat;
      viaLon = halts[0].lon;
    }

    // 1. Fetch real highway turn-by-turn road geometry via TomTom or OSRM
    let roadPoints = null;
    try {
      roadPoints = await fetchRoadGeometry(origLat, origLon, destLat, destLon, viaLat, viaLon);
    } catch (err) {
      console.warn('Real highway geometry fetch failed:', err);
    }

    // Guard against stale response if another query was fired in the meantime
    if (renderId !== currentMapRenderId) return;

    let polylineCoords = [];
    if (roadPoints && roadPoints.length > 5) {
      polylineCoords = roadPoints;
    } else if (route.highway_waypoints && route.highway_waypoints.length > 0) {
      polylineCoords = route.highway_waypoints.map(wp => [wp.lat, wp.lon]);
    } else {
      polylineCoords = [[origLat, origLon], [destLat, destLon]];
    }

    polylineCoords.forEach(pt => allCoords.push(pt));

    // Draw Real Highway Polyline (Google Green)
    L.polyline(polylineCoords, {
      color: '#188038',
      weight: 5,
      opacity: 0.95,
      smoothFactor: 1,
    }).addTo(flightMap);

    // Origin Road Marker
    const origIcon = L.divIcon({
      className: 'google-map-pin origin',
      html: `<span>START: ${route.origin.iata}</span>`,
      iconSize: [88, 26],
      iconAnchor: [44, 13],
    });
    L.marker([origLat, origLon], { icon: origIcon })
      .bindTooltip(`<b>Origin: ${route.origin.name}</b><br><span class="text-xs text-[#188038]">Departure Highway Gateway</span>`, { direction: 'top' })
      .addTo(flightMap);

    // Destination Road Marker
    const destIcon = L.divIcon({
      className: 'google-map-pin dest',
      html: `<span>END: ${route.destination.iata}</span>`,
      iconSize: [88, 26],
      iconAnchor: [44, 13],
    });
    L.marker([destLat, destLon], { icon: destIcon })
      .bindTooltip(`<b>Destination: ${route.destination.name}</b><br><span class="text-xs text-[#188038]">Arrival Corridor Terminal</span>`, { direction: 'top' })
      .addTo(flightMap);

    // Snap Intermediate Halts directly onto the real road polyline
    if (halts && halts.length > 0) {
      const haltRatios = halts.length === 1 ? [0.50] :
                         halts.length === 2 ? [0.33, 0.67] :
                         halts.length === 3 ? [0.24, 0.50, 0.80] :
                         halts.map((_, i) => (i + 1) / (halts.length + 1));

      halts.forEach((halt, idx) => {
        let hLat = halt.lat;
        let hLon = halt.lon;
        if (polylineCoords.length >= 10) {
          const ratio = haltRatios[idx] || (idx + 1) / (halts.length + 1);
          const snapIdx = Math.min(polylineCoords.length - 1, Math.max(0, Math.floor(polylineCoords.length * ratio)));
          hLat = polylineCoords[snapIdx][0];
          hLon = polylineCoords[snapIdx][1];
        }

        if (hLat && hLon) {
          allCoords.push([hLat, hLon]);
          const haltIcon = L.divIcon({
            className: 'google-map-pin halt',
            html: `<span>HALT ${idx + 1}</span>`,
            iconSize: [68, 24],
            iconAnchor: [34, 12],
          });
          const haltTitle = halt.location_name || halt.name || `Waypoint Halt ${idx + 1}`;
          const haltTime = halt.estimated_drive_time || halt.recommended_stop_after || '2-3 hrs';
          const haltDist = halt.distance_from_origin_miles ? `${halt.distance_from_origin_miles} mi` : (halt.est_distance_from_origin || '');
          const haltReason = halt.rationale || halt.primary_reason || 'Fuel / EV recharge & rest';
          const facs = (halt.facilities || []).slice(0, 3).join(', ');
          L.marker([hLat, hLon], { icon: haltIcon })
            .bindTooltip(`<b>${haltTitle}</b><br><span class="text-xs text-[#1a73e8]">Stop at ~${haltTime} (${haltDist})</span><br><span class="text-xs text-[#5f6368]">${haltReason}</span><br><span class="text-xs text-[#80868b]">Facilities: ${facs}</span>`, { direction: 'top' })
            .addTo(flightMap);
        }
      });
    }

    // Snap Overnight Stay / Lodging Contingencies directly onto the real road polyline
    if (stays && stays.length > 0) {
      const stayRatios = stays.length === 1 ? [0.58] :
                         stays.length === 2 ? [0.46, 0.72] :
                         stays.map((_, i) => 0.40 + (i * 0.22));

      stays.forEach((stay, idx) => {
        let sLat = stay.lat;
        let sLon = stay.lon;
        if (polylineCoords.length >= 10) {
          const ratio = stayRatios[idx] || 0.50;
          const snapIdx = Math.min(polylineCoords.length - 1, Math.max(0, Math.floor(polylineCoords.length * ratio)));
          sLat = polylineCoords[snapIdx][0];
          sLon = polylineCoords[snapIdx][1];
        }

        if (sLat && sLon) {
          allCoords.push([sLat, sLon]);
          const stayIcon = L.divIcon({
            className: 'google-map-pin stay',
            html: `<span>LODGE</span>`,
            iconSize: [64, 24],
            iconAnchor: [32, 12],
          });
          const stayLoc = stay.location || stay.city_state || 'Corridor Exit';
          const stayExit = stay.highway_exit || 'Exit';
          const stayRole = stay.strategic_role || stay.contingency_trigger || 'Rest Stop';
          L.marker([sLat, sLon], { icon: stayIcon })
            .bindTooltip(`<b>${stay.name}</b> (${(stay.tier || 'HOTEL').toUpperCase()})<br><span class="text-xs text-[#9334e6]">${stayLoc} • ${stayExit}</span><br><span class="text-xs text-[#b45309]">Contingency: ${stayRole}</span>`, { direction: 'top' })
            .addTo(flightMap);
        }
      });
    }

    // Fit bounds with comfortable padding
    const bounds = L.latLngBounds(allCoords);
    flightMap.fitBounds(bounds, { padding: [50, 50] });

  } else {
    // Airway Flight Arc Mode
    const midLat = route.midpoint.lat;
    const midLon = route.midpoint.lon;

    // Generate curved great-circle arc points
    const points = [];
    const numSteps = 40;
    for (let i = 0; i <= numSteps; i++) {
      const f = i / numSteps;
      const lat = origLat + (destLat - origLat) * f + Math.sin(Math.PI * f) * 3.5;
      const lon = origLon + (destLon - origLon) * f;
      points.push([lat, lon]);
    }

    // Draw Route Polyline (Google Blue)
    L.polyline(points, {
      color: '#1a73e8',
      weight: 3.5,
      dashArray: '6, 6',
      opacity: 0.9,
    }).addTo(flightMap);

    // Markers
    const origIcon = L.divIcon({
      className: 'google-map-pin origin',
      html: `<span>${route.origin.iata}</span>`,
      iconSize: [52, 24],
      iconAnchor: [26, 12],
    });

    const destIcon = L.divIcon({
      className: 'google-map-pin dest',
      html: `<span>${route.destination.iata}</span>`,
      iconSize: [52, 24],
      iconAnchor: [26, 12],
    });

    const midIcon = L.divIcon({
      className: 'google-map-pin',
      html: `<span>MID</span>`,
      iconSize: [44, 22],
      iconAnchor: [22, 11],
    });

    L.marker([origLat, origLon], { icon: origIcon })
      .bindTooltip(`<b>${route.origin.iata}</b>: ${route.origin.name}`, { direction: 'top' })
      .addTo(flightMap);

    L.marker([destLat, destLon], { icon: destIcon })
      .bindTooltip(`<b>${route.destination.iata}</b>: ${route.destination.name}`, { direction: 'top' })
      .addTo(flightMap);

    L.marker([midLat, midLon], { icon: midIcon })
      .bindTooltip(`En-Route Airspace Corridor`, { direction: 'top' })
      .addTo(flightMap);

    // Fit bounds with padding
    const bounds = L.latLngBounds([
      [origLat, origLon],
      [destLat, destLon],
    ]);
    flightMap.fitBounds(bounds, { padding: [40, 40] });
  }
}

/**
 * Hourly Timeline Render
 */
function renderHourlyTimeline(timeline) {
  const container = document.getElementById('hourlyTimelineScroll');
  container.innerHTML = '';

  if (!timeline || timeline.length === 0) {
    container.innerHTML = '<div class="text-xs text-gray-500 py-2">Hourly model timeline unavailable.</div>';
    return;
  }

  // Find lowest disruption hour
  let minScore = 999;
  let bestHour = 'Morning';
  timeline.forEach(h => {
    const s = h.risk_level === 'critical' ? 90 : h.risk_level === 'high' ? 70 : h.risk_level === 'medium' ? 45 : 15;
    if (s < minScore) {
      minScore = s;
      bestHour = h.hour_label;
    }
  });
  document.getElementById('bestWindowBadge').textContent = `Optimal Flight Window: ~${bestHour}`;

  timeline.forEach(item => {
    const card = document.createElement('div');
    card.className = 'flex-shrink-0 w-28 bg-white rounded-xl p-3 border border-[#dadce0] text-center flex flex-col justify-between shadow-sm';

    let badgeClass = 'text-[#137333] bg-[#e6f4ea] border border-[#a8dab5]';
    if (item.risk_level === 'high' || item.risk_level === 'critical') {
      badgeClass = 'text-[#c5221f] bg-[#fce8e6] border border-[#f5c2c7]';
    } else if (item.risk_level === 'medium') {
      badgeClass = 'text-[#b45309] bg-[#fef7e0] border border-[#fdd663]';
    }

    card.innerHTML = `
      <div class="text-[11px] font-mono text-[#5f6368] font-medium">${item.hour_label}</div>
      <div class="my-1.5">
        <div class="text-xs font-bold text-[#202124]">${item.temp_f}°F</div>
        <div class="text-[10px] text-[#5f6368] truncate" title="${item.weather_desc}">${item.weather_desc}</div>
      </div>
      <div class="text-[10px] space-y-1 pt-1.5 border-t border-[#e8eaed]">
        <div class="flex items-center justify-between text-[#5f6368]">
          <span>Precip</span>
          <span class="text-[#1a73e8] font-mono font-medium">${item.precip_prob}%</span>
        </div>
        <div class="flex items-center justify-between text-[#5f6368]">
          <span>Gusts</span>
          <span class="text-[#202124] font-mono font-medium">${item.wind_gusts_mph} mph</span>
        </div>
      </div>
      <div class="mt-2 text-[9px] uppercase font-bold px-2 py-0.5 rounded-full border ${badgeClass}">
        ${item.risk_level}
      </div>
    `;
    container.appendChild(card);
  });
}

/**
 * Operational Actions Render
 */
function renderActions(actions) {
  const travelerList = document.getElementById('travelerActionsList');
  const opsList = document.getElementById('opsActionsList');
  travelerList.innerHTML = '';
  opsList.innerHTML = '';

  actions.forEach(rec => {
    const el = document.createElement('div');
    el.className = 'p-3.5 rounded-xl bg-white border border-[#dadce0] space-y-1.5 shadow-sm hover:shadow transition';

    let priorityBadge = '<span class="text-[10px] bg-[#e8f0fe] text-[#1a73e8] border border-[#aecbfa] px-2.5 py-0.5 rounded-full font-semibold uppercase">Recommended</span>';
    if (rec.priority === 'high') {
      priorityBadge = '<span class="text-[10px] bg-[#fce8e6] text-[#d93025] border border-[#f5c2c7] px-2.5 py-0.5 rounded-full font-semibold uppercase">High Priority</span>';
    }

    el.innerHTML = `
      <div class="flex items-center justify-between">
        <h4 class="text-xs font-bold text-[#202124]">${rec.title}</h4>
        ${priorityBadge}
      </div>
      <p class="text-xs text-[#1a73e8] font-semibold">${rec.action}</p>
      <p class="text-[11px] text-[#5f6368] leading-relaxed">${rec.rationale}</p>
    `;

    if (rec.target === 'traveler') {
      travelerList.appendChild(el);
    } else {
      opsList.appendChild(el);
    }
  });

  if (travelerList.children.length === 0) {
    travelerList.innerHTML = '<div class="text-xs text-[#5f6368] p-2">Standard travel protocols apply.</div>';
  }
  if (opsList.children.length === 0) {
    opsList.innerHTML = '<div class="text-xs text-[#5f6368] p-2">Standard monitoring protocols apply.</div>';
  }
}

/**
 * Uncertainty Panel Render
 */
function renderUncertainty(unc) {
  document.getElementById('confidenceScoreVal').textContent = `${unc.confidence_score}%`;

  const confList = document.getElementById('confirmedFactorsList');
  const varList = document.getElementById('forecastVariablesList');
  const sensList = document.getElementById('sensitivityDriversList');

  confList.innerHTML = unc.confirmed_factors.map(f => `<li>${f}</li>`).join('') || '<li>None reported</li>';
  varList.innerHTML = unc.forecast_variables.map(v => `<li>${v}</li>`).join('') || '<li>Standard variance</li>';
  sensList.innerHTML = unc.sensitivity_drivers.map(s => `<li>${s}</li>`).join('') || '<li>Standard parameters</li>';
}

/**
 * Evidence Dossier Render with Collapsible Telemetry
 */
function renderEvidence() {
  const container = document.getElementById('evidenceList');
  container.innerHTML = '';

  if (!currentAssessment || !currentAssessment.evidence) return;

  const items = currentAssessment.evidence.filter(e => {
    if (activeEvidenceFilter === 'all') return true;
    return e.category === activeEvidenceFilter;
  });

  if (items.length === 0) {
    container.innerHTML = '<div class="col-span-2 text-xs text-gray-500 py-6 text-center">No telemetry items in this category.</div>';
    return;
  }

  items.forEach((item, idx) => {
    const card = document.createElement('div');
    card.className = 'bg-white rounded-xl border border-[#dadce0] p-4 space-y-2.5 flex flex-col justify-between shadow-sm hover:border-[#bdc1c6] transition';

    let sevBadge = 'text-[#5f6368] bg-[#f1f3f4]';
    if (item.severity === 'critical') sevBadge = 'text-[#c5221f] bg-[#fce8e6] border border-[#f5c2c7]';
    else if (item.severity === 'high') sevBadge = 'text-[#b45309] bg-[#fef7e0] border border-[#fdd663]';
    else if (item.severity === 'medium') sevBadge = 'text-[#1a73e8] bg-[#e8f0fe] border border-[#aecbfa]';

    const rawId = `raw-telemetry-${idx}`;

    card.innerHTML = `
      <div>
        <div class="flex items-center justify-between text-[11px] mb-1.5">
          <span class="font-bold text-[#1a73e8] font-mono">${item.source}</span>
          <span class="text-[10px] uppercase font-bold px-2.5 py-0.5 rounded-full ${sevBadge}">${item.severity}</span>
        </div>
        <h4 class="text-xs font-bold text-[#202124]">${item.title}</h4>
        <p class="text-xs text-[#5f6368] mt-1 leading-relaxed">${item.detail}</p>
      </div>

      ${item.raw_data ? `
        <div class="pt-2 border-t border-[#e8eaed]">
          <button class="text-[11px] text-[#1a73e8] hover:underline flex items-center gap-1 font-mono toggle-raw-btn" data-target="${rawId}">
            <span>Inspect Raw Telemetry</span>
            <span class="text-[#80868b] text-[10px]">&darr;</span>
          </button>
          <pre id="${rawId}" class="hidden mt-2 p-2.5 bg-[#f8f9fa] rounded-lg border border-[#dadce0] text-[10px] text-[#188038] font-mono whitespace-pre-wrap overflow-x-auto max-h-36">${escapeHtml(item.raw_data)}</pre>
        </div>
      ` : ''}
    `;

    container.appendChild(card);
  });

  // Toggle raw pre
  container.querySelectorAll('.toggle-raw-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const targetId = btn.getAttribute('data-target');
      const el = document.getElementById(targetId);
      el.classList.toggle('hidden');
    });
  });
}

function escapeHtml(text) {
  return text
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;');
}

/**
 * Basic Markdown to HTML formatter for Briefing
 */
function formatMarkdown(md) {
  if (!md) return '';
  let html = md
    .replace(/^### (.*$)/gim, '<h3 class="text-xs font-bold text-[#202124] uppercase tracking-wider mt-3 mb-1">$1</h3>')
    .replace(/^## (.*$)/gim, '<h2 class="text-sm font-bold text-[#202124] mt-3.5 mb-1.5">$1</h2>')
    .replace(/^\*\*([^*]+)\*\*/gim, '<strong class="text-[#202124] font-semibold">$1</strong>')
    .replace(/\*\*([^*]+)\*\*/g, '<strong class="text-[#202124] font-semibold">$1</strong>')
    .replace(/^- (.*$)/gim, '<li class="ml-4 list-disc text-[#3c4043] my-0.5">$1</li>')
    .replace(/\n\n/g, '<div class="h-2"></div>')
    .replace(/\n/g, '<br>');
  return html;
}

/**
 * Render Interstate Roadway Hazards, Waypoint Halts, and Stay/Motel Contingencies
 */
function renderRoadwayAndStays(data) {
  const badge = document.getElementById('roadwayStatsBadge');
  const route = data.route;
  const interstates = (route.primary_interstates || []).join(' / ');
  badge.innerHTML = `<span class="text-[#188038] font-semibold uppercase tracking-wider text-[11px] mr-1">Corridor:</span><strong>${route.driving_distance_miles?.toLocaleString() || 'N/A'} mi</strong> <span class="text-[#5f6368] font-normal">(~${route.driving_time_est || 'N/A'})</span> &bull; <span class="text-[#1a73e8] font-mono">${interstates}</span>`;

  // 1. Roadway Disruptions
  const dispList = document.getElementById('roadwayDisruptionsList');
  dispList.innerHTML = '';
  const roadDisruptions = data.roadway_disruptions || [];
  if (roadDisruptions.length === 0) {
    dispList.innerHTML = '<div class="col-span-2 text-xs text-[#5f6368] p-3 bg-white rounded-xl border border-[#dadce0] text-center shadow-sm">Standard highway conditions. No road weather advisories.</div>';
  } else {
    roadDisruptions.forEach(rd => {
      const el = document.createElement('div');
      let badgeColor = 'text-[#1a73e8] bg-[#e8f0fe] border border-[#aecbfa]';
      if (rd.severity === 'critical' || rd.severity === 'high') {
        badgeColor = 'text-[#c5221f] bg-[#fce8e6] border border-[#f5c2c7]';
      } else if (rd.severity === 'medium') {
        badgeColor = 'text-[#b45309] bg-[#fef7e0] border border-[#fdd663]';
      }
      el.className = 'p-3.5 bg-white rounded-xl border border-[#dadce0] space-y-1.5 shadow-sm hover:border-[#bdc1c6] transition';
      el.innerHTML = `
        <div class="flex items-center justify-between text-[11px]">
          <span class="font-bold text-[#202124] font-mono">${rd.highway}</span>
          <span class="text-[10px] uppercase font-bold px-2 py-0.5 rounded-full ${badgeColor}">${rd.condition_type}</span>
        </div>
        <div class="text-xs text-[#1a73e8] font-semibold">${rd.segment}</div>
        <p class="text-[11px] text-[#3c4043] leading-relaxed">${rd.description}</p>
        <div class="text-[10px] text-[#5f6368] pt-1 border-t border-[#e8eaed] flex justify-between">
          <span>Est. Highway Delay: +${rd.delay_estimate_minutes}m</span>
          <span>Source: ${rd.source}</span>
        </div>
      `;
      dispList.appendChild(el);
    });
  }

  // 2. Halts along the way
  const haltList = document.getElementById('haltSuggestionsList');
  haltList.innerHTML = '';
  const halts = data.halt_suggestions || [];
  if (halts.length === 0) {
    haltList.innerHTML = `
      <div class="p-3.5 bg-white rounded-xl border border-[#dadce0] text-center text-xs text-[#5f6368] space-y-1 shadow-sm">
        <div class="text-[#188038] font-semibold flex items-center justify-center gap-1.5">
          <i data-lucide="check-circle" class="w-3.5 h-3.5"></i>
          <span>Nonstop Express Highway Routing</span>
        </div>
        <p class="text-[11px] text-[#5f6368]">Continuous direct driving: total transit duration is within standard driver alertness thresholds (~2.5–3 hours), or nonstop mode was selected.</p>
      </div>
    `;
    lucide.createIcons();
  } else {
    halts.forEach(h => {
      const el = document.createElement('div');
      el.className = 'p-3.5 bg-white rounded-xl border border-[#dadce0] space-y-2 shadow-sm hover:border-[#bdc1c6] transition';
      el.innerHTML = `
        <div class="flex items-center justify-between">
          <div class="flex items-center gap-1.5 flex-wrap">
            <span class="w-5 h-5 rounded-full bg-[#e8f0fe] text-[#1a73e8] text-[10px] flex items-center justify-center font-mono font-bold">${h.stop_number}</span>
            <span class="text-xs font-bold text-[#202124]">${h.location_name}</span>
            ${h.city ? `<span class="text-[10px] font-semibold bg-[#e8f0fe] text-[#1a73e8] border border-[#aecbfa] px-2 py-0.5 rounded-full font-sans">📍 ${h.city}${h.state ? ', ' + h.state : ''}</span>` : ''}
          </div>
          <span class="text-[10px] font-mono text-[#188038] font-semibold">${h.estimated_drive_time} (~${h.distance_from_origin_miles} mi)</span>
        </div>
        <div class="text-[10px] font-mono text-[#5f6368]">
          <span class="text-[#202124] font-semibold">${h.highway}</span> &bull; <span>${h.mile_marker || 'MM Transit'}</span>
        </div>
        <p class="text-[11px] text-[#3c4043] leading-relaxed"><strong class="text-[#1a73e8]">Driver Focus & Recharge:</strong> ${h.rationale}</p>
        <div class="flex flex-wrap gap-1 pt-0.5">
          ${(h.facilities || []).map(f => `<span class="text-[9px] bg-[#f1f3f4] text-[#3c4043] px-2 py-0.5 rounded-full border border-[#dadce0] font-medium">${f}</span>`).join('')}
        </div>
      `;
      haltList.appendChild(el);
    });
  }

  // 3. Stay / Motel Recommendations
  const stayList = document.getElementById('stayRecommendationsList');
  stayList.innerHTML = '';
  const stays = data.stay_recommendations || [];
  stays.forEach(s => {
    const el = document.createElement('div');
    el.className = 'p-3.5 bg-white rounded-xl border border-[#dadce0] space-y-2 shadow-sm hover:border-[#bdc1c6] transition';
    let tierBadge = 'bg-[#e8f0fe] text-[#1a73e8] border border-[#aecbfa]';
    if (s.tier === 'emergency_shelter') tierBadge = 'bg-[#fce8e6] text-[#c5221f] border border-[#f5c2c7]';
    else if (s.tier === 'budget_motel') tierBadge = 'bg-[#fef7e0] text-[#b45309] border border-[#fdd663]';

    el.innerHTML = `
      <div class="flex items-center justify-between">
        <div>
          <h5 class="text-xs font-bold text-[#202124]">${s.name}</h5>
          <span class="text-[10px] text-[#5f6368] font-mono">${s.location} (${s.highway_exit})</span>
        </div>
        <div class="text-right">
          <span class="text-[9px] uppercase font-bold px-2 py-0.5 rounded-full border ${tierBadge}">${s.tier.replace('_', ' ')}</span>
          <span class="text-[10px] font-mono text-[#5f6368] block mt-0.5">${s.price_tier}</span>
        </div>
      </div>
      <p class="text-[11px] text-[#3c4043] leading-relaxed">${s.strategic_role}</p>
      <div class="bg-[#f8f9fa] p-2.5 rounded-lg border border-[#dadce0] text-[10px] text-[#202124]">
        <span class="text-[#5f6368] font-bold uppercase tracking-wider text-[9px] mr-1">Contingency Trigger:</span>${s.contingency_trigger}
      </div>
      <div class="flex flex-wrap gap-1 pt-0.5">
        ${(s.amenities || []).map(a => `<span class="text-[9px] bg-[#f1f3f4] text-[#5f6368] px-2 py-0.5 rounded-full border border-[#dadce0]">${a}</span>`).join('')}
      </div>
    `;
    stayList.appendChild(el);
  });
}

/**
 * Render Evaluated Alternate Routes & Co-Terminal Bypasses
 */
function renderAlternateRoutes(alternateRoutes) {
  const container = document.getElementById('alternateRoutesList');
  const section = document.getElementById('alternateRoutesSection');
  if (!container || !section) return;

  container.innerHTML = '';

  if (!alternateRoutes || alternateRoutes.length === 0) {
    container.innerHTML = `
      <div class="col-span-2 p-4 bg-white rounded-xl border border-[#dadce0] text-center text-xs text-[#5f6368] shadow-sm">
        Direct route corridor is currently optimal. No higher-efficiency alternate bypasses required.
      </div>
    `;
    return;
  }

  alternateRoutes.forEach(alt => {
    const card = document.createElement('div');
    card.className = 'p-5 bg-white rounded-2xl border border-[#dadce0] hover:border-[#1a73e8] hover:shadow-md transition shadow-sm flex flex-col justify-between space-y-3';

    const isRoad = alt.travel_mode === 'road';
    const modeBadge = isRoad ? 'bg-[#e6f4ea] text-[#188038] border border-[#a8dab5]' : 'bg-[#e8f0fe] text-[#1a73e8] border border-[#aecbfa]';
    const reductionBadge = alt.risk_reduction_points > 0 
      ? `<span class="text-[10px] bg-[#e6f4ea] text-[#137333] font-bold px-2.5 py-0.5 rounded-full border border-[#a8dab5]">-${alt.risk_reduction_points} PTS RISK REDUCTION</span>`
      : `<span class="text-[10px] bg-[#f1f3f4] text-[#5f6368] px-2.5 py-0.5 rounded-full border border-[#dadce0]">ALTERNATIVE CORRIDOR</span>`;

    card.innerHTML = `
      <div>
        <div class="flex items-center justify-between text-xs mb-2">
          <div class="flex items-center gap-1.5">
            <span class="text-[9px] uppercase font-bold px-2 py-0.5 rounded-full border ${modeBadge}">${alt.travel_mode.toUpperCase()}</span>
            ${reductionBadge}
          </div>
          <span class="text-[11px] font-mono font-bold text-[#202124]">Projected: ${alt.projected_risk_score}/100 (${alt.projected_risk_level})</span>
        </div>

        <h4 class="text-sm font-bold text-[#202124] mb-1">${escapeHtml(alt.title)}</h4>
        <div class="text-[11px] text-[#5f6368] font-mono mb-2.5">
          ${alt.origin_code} → ${alt.destination_code} • ${escapeHtml(alt.estimated_duration)}
        </div>

        <div class="space-y-2 text-xs">
          <div class="flex items-start gap-2 text-[#137333] bg-[#e6f4ea] p-2.5 rounded-xl border border-[#ceead6]">
            <i data-lucide="check-circle-2" class="w-3.5 h-3.5 mt-0.5 flex-shrink-0 text-[#188038]"></i>
            <span class="leading-relaxed"><strong>Operational Advantage:</strong> ${escapeHtml(alt.key_benefit)}</span>
          </div>
          <div class="flex items-start gap-2 text-[#b45309] bg-[#fef7e0] p-2.5 rounded-xl border border-[#feefc3]">
            <i data-lucide="clock" class="w-3.5 h-3.5 mt-0.5 flex-shrink-0 text-[#f29900]"></i>
            <span class="leading-relaxed"><strong>Tradeoff:</strong> ${escapeHtml(alt.tradeoff)}</span>
          </div>
        </div>
      </div>

      <div class="pt-3 border-t border-[#e8eaed] flex items-center justify-between">
        <span class="text-[10px] text-[#5f6368] font-mono">One-Click Reroute</span>
        <button type="button" class="switch-route-btn btn-google-primary px-3.5 py-1.5 text-xs font-semibold flex items-center gap-1 shadow-sm"
          data-orig="${alt.origin_code}" data-dest="${alt.destination_code}" data-mode="${alt.travel_mode}">
          <i data-lucide="corner-down-right" class="w-3.5 h-3.5"></i>
          <span>Switch to This Route</span>
        </button>
      </div>
    `;

    container.appendChild(card);
  });

  // Attach click listeners to Switch Route buttons
  container.querySelectorAll('.switch-route-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const orig = btn.getAttribute('data-orig');
      const dest = btn.getAttribute('data-dest');
      const mode = btn.getAttribute('data-mode') || 'air';

      // Update form inputs
      const origInput = document.getElementById('originInput');
      const destInput = document.getElementById('destinationInput');
      const travelDateInput = document.getElementById('travelDateInput');
      const timeWindow = document.getElementById('timeWindowSelect')?.value || 'all_day';

      if (origInput) origInput.value = orig;
      if (destInput) destInput.value = dest;

      // Update travel mode tab
      const modeBtn = document.querySelector(`.mode-tab-btn[data-mode="${mode}"]`);
      if (modeBtn) modeBtn.click();

      // Submit assessment for the alternate route!
      const targetDate = travelDateInput ? travelDateInput.value : getIsoDate(1);
      showToast(`Switched corridor to alternate route: ${orig} → ${dest}`, 'git-fork', 'info');
      submitAssessment(orig, dest, targetDate, timeWindow);

      // Smooth scroll to top of results
      document.getElementById('resultsContainer')?.scrollIntoView({ behavior: 'smooth' });
    });
  });

  lucide.createIcons();
}

/**
 * Interactive Journey Disruption AI Companion
 */
function initJourneyChatAssistant() {
  const form = document.getElementById('journeyChatForm');
  const input = document.getElementById('journeyChatInput');
  const stream = document.getElementById('journeyChatStream');
  const sendBtn = document.getElementById('journeyChatSendBtn');
  const chipsContainer = document.getElementById('journeyChatChips');

  if (!form || !input || !stream) return;

  const sidePanel = document.getElementById('journeyChatSidePanel');
  const floatingBtn = document.getElementById('floatingChatTriggerBtn');
  const minimizeBtn = document.getElementById('minimizeChatBtn');
  const clearBtn = document.getElementById('clearChatBtn');
  const navChatBtn = document.getElementById('navOpenChatBtn');

  // Minimize Side Dock
  if (minimizeBtn) {
    minimizeBtn.addEventListener('click', () => {
      if (sidePanel) sidePanel.classList.add('hidden');
      if (floatingBtn) floatingBtn.classList.remove('hidden');
    });
  }

  // Expand / Maximize Side Dock
  const expandBtn = document.getElementById('expandChatBtn');
  const expandIcon = document.getElementById('expandChatIcon');
  if (expandBtn) {
    expandBtn.addEventListener('click', () => {
      if (!sidePanel) return;
      const isExpanded = sidePanel.classList.toggle('chat-expanded');
      expandBtn.setAttribute('title', isExpanded ? 'Restore Compact Dock' : 'Expand Chat Screen');
      if (expandIcon) {
        expandIcon.setAttribute('data-lucide', isExpanded ? 'minimize-2' : 'maximize-2');
        lucide.createIcons();
      }
    });
  }

  // Open & Focus Side Dock
  function openChatDock() {
    if (sidePanel) {
      sidePanel.classList.remove('hidden');
      lucide.createIcons();
    }
    if (floatingBtn) floatingBtn.classList.add('hidden');
    if (input) input.focus();
  }

  if (floatingBtn) {
    floatingBtn.addEventListener('click', openChatDock);
  }

  if (navChatBtn) {
    navChatBtn.addEventListener('click', openChatDock);
  }

  // Clear Chat History
  if (clearBtn) {
    clearBtn.addEventListener('click', () => {
      stream.innerHTML = `
        <div class="flex items-start gap-2.5">
          <div class="w-6 h-6 rounded-full bg-[#e8f0fe] text-[#1a73e8] flex items-center justify-center flex-shrink-0 text-[10px] font-bold font-mono">AI</div>
          <div class="bg-white border border-[#dadce0] p-3 rounded-2xl text-[#202124] space-y-1 shadow-sm">
            <p class="font-semibold text-[#202124]">Chat history cleared.</p>
            <p class="text-[#5f6368] leading-relaxed text-[11px]">How can I assist you with your travel route?</p>
          </div>
        </div>
      `;
      showToast('Chat conversation reset', 'rotate-ccw', 'info');
    });
  }

  // Handle Quick Chips
  document.querySelectorAll('.journey-chip').forEach(chip => {
    chip.addEventListener('click', () => {
      const promptText = chip.getAttribute('data-prompt');
      if (promptText) {
        input.value = promptText;
        form.dispatchEvent(new Event('submit'));
      }
    });
  });

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const query = input.value.trim();
    if (!query) return;

    input.value = '';
    sendBtn.disabled = true;

    // Concurrency cancellation for in-flight chat stream
    if (activeChatController) {
      activeChatController.abort();
    }
    activeChatController = new AbortController();

    // Append User Message
    appendChatMessage('user', query);

    // Typing indicator
    const typingId = 'typing-' + Date.now();
    const typingEl = document.createElement('div');
    typingEl.id = typingId;
    typingEl.className = 'flex items-start gap-2.5';
    typingEl.innerHTML = `
      <div class="w-6 h-6 rounded-full bg-[#e8f0fe] text-[#1a73e8] flex items-center justify-center flex-shrink-0 text-[10px] font-bold font-mono">AI</div>
      <div class="bg-white border border-[#dadce0] p-3 rounded-2xl max-w-2xl text-[#5f6368] italic flex items-center gap-2 shadow-sm text-xs">
        <span class="w-2 h-2 rounded-full bg-[#1a73e8] animate-ping"></span>
        <span>Evaluating operational telemetry & synthesizing guidance...</span>
      </div>
    `;
    stream.appendChild(typingEl);
    stream.scrollTop = stream.scrollHeight;

    const apiKey = localStorage.getItem('strata_gemini_api_key') || null;

    try {
      const resp = await fetch('/api/chat-assistant', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        signal: activeChatController.signal,
        body: JSON.stringify({
          message: query,
          assessment_context: currentAssessment,
          gemini_api_key: apiKey,
        }),
      });

      const typing = document.getElementById(typingId);
      if (typing) typing.remove();

      if (!resp.ok) {
        throw new Error('Chat service temporarily unavailable.');
      }

      const data = await resp.json();
      appendChatMessage('ai', data.reply);

      // Update follow-up chips if returned
      if (data.suggested_questions && data.suggested_questions.length > 0 && chipsContainer) {
        chipsContainer.innerHTML = '';
        data.suggested_questions.forEach(q => {
          const btn = document.createElement('button');
          btn.type = 'button';
          btn.className = 'journey-chip google-chip text-[11px] cursor-pointer';
          btn.setAttribute('data-prompt', q);
          btn.textContent = `💡 ${q}`;
          btn.addEventListener('click', () => {
            input.value = q;
            form.dispatchEvent(new Event('submit'));
          });
          chipsContainer.appendChild(btn);
        });
      }

    } catch (err) {
      if (err.name === 'AbortError') return;
      const typing = document.getElementById(typingId);
      if (typing) typing.remove();
      appendChatMessage('ai', `⚠️ Unable to process query: ${err.message}`);
    } finally {
      sendBtn.disabled = false;
      stream.scrollTop = stream.scrollHeight;
    }
  });

  function appendChatMessage(sender, text) {
    const msgEl = document.createElement('div');
    msgEl.className = 'flex items-start gap-2.5';

    if (sender === 'user') {
      msgEl.innerHTML = `
        <div class="w-6 h-6 rounded-full bg-[#1a73e8] text-white flex items-center justify-center flex-shrink-0 text-[10px] font-bold font-mono shadow-sm">YOU</div>
        <div class="bg-[#e8f0fe] border border-[#aecbfa] p-3 rounded-2xl max-w-2xl text-[#174ea6] font-medium text-xs leading-relaxed shadow-sm">
          ${escapeHtml(text)}
        </div>
      `;
    } else {
      msgEl.innerHTML = `
        <div class="w-6 h-6 rounded-full bg-[#e8f0fe] text-[#1a73e8] flex items-center justify-center flex-shrink-0 text-[10px] font-bold font-mono">AI</div>
        <div class="bg-white border border-[#dadce0] p-3.5 rounded-2xl max-w-2xl text-[#202124] space-y-2 leading-relaxed text-xs shadow-sm">
          ${formatMarkdown(text)}
        </div>
      `;
    }

    stream.appendChild(msgEl);
    stream.scrollTop = stream.scrollHeight;
    lucide.createIcons();
  }
}

/**
 * Interactive What-If Scenario Sensitivity Simulator
 */
function initWhatIfSimulator() {
  const resultBox = document.getElementById('whatIfResultBox');
  if (!resultBox) return;

  document.querySelectorAll('.whatif-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const scenario = btn.getAttribute('data-scenario');
      resultBox.classList.remove('hidden');

      if (scenario === 'early_window') {
        resultBox.innerHTML = `
          <strong>⏱️ SIMULATION: Shift Departure to Early Morning (06:00-09:00)</strong><br>
          &bull; Terminal Runway Congestion: Reduced by <strong>-55%</strong> (Early bank departure slot).<br>
          &bull; Convective Thunderstorm Probability: Drops from 65% to <strong>8%</strong>.<br>
          &bull; Projected Delay Risk: <strong>LOW (18%)</strong> &bull; Expected Delay: <strong>0-15 min</strong>.
        `;
      } else if (scenario === 'storm_intensifies') {
        resultBox.innerHTML = `
          <strong>⛈️ SIMULATION: Severe Frontal Intensification (+30% Precip / 45kt Gusts)</strong><br>
          &bull; FAA ATCSCC Trigger: Initiates formal <strong>Ground Delay Program (GDP)</strong>.<br>
          &bull; Expected Ground Delay: Escalates to <strong>75-110 min</strong>.<br>
          &bull; Missed Connection Risk: Spikes to <strong>88% (CRITICAL)</strong>. Recommend immediate backup rebooking.
        `;
      } else if (scenario === 'ground_stop_lifted') {
        resultBox.innerHTML = `
          <strong>🟢 SIMULATION: Ground Stop Termination / Visual Approach Restored</strong><br>
          &bull; Arrival Acceptance Rate: Restored to <strong>60 aircraft/hour</strong>.<br>
          &bull; Backlog Clearance: Flight meter delays clear within approximately <strong>45 minutes</strong>.<br>
          &bull; On-Time Departure Probability: Rises to <strong>84%</strong>.
        `;
      }
    });
  });
}


